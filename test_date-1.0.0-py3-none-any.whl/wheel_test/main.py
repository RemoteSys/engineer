from wheel_test.src import functions as fn


def main():
    fn.show_current_datetime()


if __name__ == '__main__':
    main()
