from datetime import datetime

def show_current_datetime():
    now = datetime.now()
    # date formating: %A: name of day
    date_str = now.strftime("%d.%m.%Y (%A)")
    time_str = now.strftime("%H:%M")
    print(f"{'Today:': >7}  {date_str}")
    print(f"{'Time:': >7}  {time_str}")
